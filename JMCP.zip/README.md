# JMCP

[中文](#中文) · [English](#english)

<a id="中文"></a>

# 中文

JMCP 是一个给 AI 客户端使用的远程 Linux / VPS MCP Server，提供 OAuth 2.1、Passkey、Dashboard、远程命令执行、文件操作和可选 GUI 操控。

## 使用前必须知道

> **仅支持有域名的 VPS 使用。IP 不支持直接使用。**
> 
> `BASE_URL` 必须使用一个可从公网访问的 HTTPS 域名。不要把 `http://IP:端口` 当作 JMCP 的公网地址直接使用。

> **VPS 后台操作不同。**
> 
> 不同 VPS / 主机商的进程管理、Node.js 配置、端口映射、反向代理、Web 服务和保活方式都可能不同。必须在确保 **JMCP 主程序持续保活** 的同时，确保 **WebSite Dashboard 可以正常访问**。不要为了保活主程序而把 WebSite / Dashboard 的服务入口一起停掉。

> **AI 操作免责声明：AI 的任何操作与本人无关。**
> 
> 使用 JMCP 时，AI 客户端可能通过 MCP 执行命令、读写文件或进行其他允许的操作。相关操作由连接 JMCP 的 AI 客户端发起，项目作者/用户不对 AI 自主执行的任何操作、结果或后果承担责任。

> **绝对不要把 sudo password 提供给 Agent。**
> 
> JMCP 的 Agent 不需要知道你的 sudo password。不要在聊天、MCP 参数、环境变量、文件或任何其他位置把 sudo password 提供给 Agent。需要 root 权限的系统操作应由 VPS 管理员通过主机商后台或自己的安全管理流程完成。

## 快速开始

```bash
sh install.sh
npm start
```

安装脚本会让你选择中文/English，并配置 `BASE_URL`、管理员密码和可选 GUI。工作区默认为 `$HOME/mcp-workspace`。

Dashboard：`你的域名/dashboard`

MCP：`你的域名/mcp`

## Dashboard

Dashboard 内置 **中文 / English** 切换，语言选择会保存在浏览器本地。主要功能：

- VPS 状态：CPU、内存、磁盘、运行时间
- 连接概览：工作区、授权连接、Passkey、GUI 状态
- 授权连接：重命名、永久撤销 Token
- 工作区：查看工作目录，并在身份验证后清空
- 修改管理员密码
- Passkey：添加、重命名、删除
- ChatGPT / 手动客户端：生成 `client_id` / `client_secret`

## Agent 与安全

MCP 中的危险命令会要求客户端先取得用户明确确认，再使用 `confirmed:true` 执行。

工作区不会自动删除。清空工作区需要 JMCP 登录密码或 Dashboard 的 Passkey 二次验证。

Token 为永久有效，泄露后的风险也会持续存在。请在 Dashboard 中撤销不再使用的连接。

**再次强调：不要把 sudo password 给 Agent。**

## GUI 操控

可选 GUI 工具依赖 `Xvfb`、`xdotool`、`scrot`，或者已有的 VNC / X 桌面。共享虚拟主机可能没有安装系统软件所需的权限，因此 GUI 功能可能不可用。

## VPS 保活与 Website Dashboard

JMCP 是主程序，Dashboard 是网站入口，两者都必须保持可用。不同 VPS 后台的进程管理方式不同，可能需要分别配置 Node.js 应用保活、反向代理和网站入口。**不要只保证 `npm start` 活着，却让 Dashboard 的 Web 服务入口停止。**

## ChatGPT 接入

对于不支持自动客户端注册的平台，可以在 Dashboard 的“ChatGPT / 手动客户端接入”区域生成 `client_id` / `client_secret`，然后配置：

- Authorize URL：`你的域名/authorize`
- Token URL：`你的域名/token`
- MCP URL：`你的域名/mcp`

<a id="english"></a>

# English

JMCP is a remote Linux / VPS MCP Server for AI clients. It provides OAuth 2.1, Passkey authentication, a web Dashboard, remote command execution, file operations, and optional GUI control.

## Read This Before Using JMCP

> **DOMAIN-BASED VPS USE ONLY. Direct IP access is NOT supported.**
> 
> `BASE_URL` must use a publicly reachable **HTTPS domain name**. Do not use `http://IP:port` as the public JMCP address.

> **VPS control panels work differently.**
> 
> Process management, Node.js configuration, port mapping, reverse proxies, web services, and keep-alive mechanisms vary between VPS providers. You must keep the **main JMCP process alive** while also keeping the **Website Dashboard accessible and working**. Do not keep the main process alive by accidentally disabling the Website / Dashboard service entry.

> **AI operation disclaimer: any action performed by an AI is unrelated to and not the responsibility of the user.**
> 
> An AI client connected to JMCP may execute commands, read/write files, or perform other permitted operations. Such operations are initiated by the connected AI client. The project author/user assumes no responsibility for autonomous AI actions, their results, or their consequences.

> **DO NOT PROVIDE YOUR SUDO PASSWORD TO THE AGENT.**
> 
> The JMCP Agent does not need your sudo password. Never provide it through chat, MCP parameters, environment variables, files, or any other channel. System-level operations requiring root privileges should be performed by the VPS administrator through the provider's control panel or another secure administrative workflow.

## Quick Start

```bash
sh install.sh
npm start
```

The installer lets you choose Chinese or English and configure `BASE_URL`, the admin password, and optional GUI support. The default workspace is `$HOME/mcp-workspace`.

Dashboard: `your-domain/dashboard`

MCP: `your-domain/mcp`

## Dashboard

The Dashboard supports a **Chinese / English** language switch. The selected language is stored locally in the browser. Features include:

- VPS status: CPU, memory, disk, and uptime
- Connection overview: workspace, authorized connections, Passkeys, and GUI status
- Authorized connections: rename and permanently revoke tokens
- Workspace: inspect the workspace and clear it after identity verification
- Admin password change
- Passkey management: add, rename, and delete
- ChatGPT / manual client: generate `client_id` / `client_secret`

## Agent and Security

Dangerous MCP commands require explicit user confirmation before the client can execute them with `confirmed:true`.

The workspace is not automatically deleted. Clearing it requires the JMCP login password or Dashboard Passkey step-up verification.

Tokens are permanent. A leaked token therefore remains a long-term security risk. Revoke unused connections from the Dashboard.

**Again: NEVER give your sudo password to the Agent.**

## GUI Control

Optional GUI tools depend on `Xvfb`, `xdotool`, and `scrot`, or an existing VNC / X desktop. Shared hosting may not provide permission to install system packages, so GUI control can be unavailable.

## VPS Keep-Alive and Website Dashboard

JMCP is the main application, while the Dashboard is its website entry point. Both must remain available. VPS control panels differ, so Node.js process keep-alive, reverse proxy configuration, and the website entry may need to be managed separately. **Do not keep `npm start` alive while allowing the Dashboard web entry to stop working.**

## ChatGPT Integration

For platforms without automatic client registration, use Dashboard → “ChatGPT / Manual Client” to generate `client_id` / `client_secret`, then configure:

- Authorize URL: `your-domain/authorize`
- Token URL: `your-domain/token`
- MCP URL: `your-domain/mcp`

## Language Support

`Dashboard`: use the language buttons at the top.

`install.sh`: choose `1=中文` or `2=English` when the script starts.

`README.md`: use the language links at the top to jump between the Chinese and English documentation.
