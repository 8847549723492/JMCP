// JMCP — 远程命令执行 MCP Server (v3)
//
// v3 新增：
//   - UI改为奶油黄柔和配色
//   - Dashboard新增VPS状态(CPU/RAM/磁盘)
//   - 标题去掉emoji
//   - Token永久有效，单独存成文件（data/tokens/<token>.json）
//   - Dashboard功能区可折叠（三角图标：展开朝上，收起朝下）
//   - 授权页(/authorize)也支持Passkey登录
//   - 支持ChatGPT自定义连接（client_secret模式的手动客户端）
//   - Token/Passkey均可重命名、删除

import "dotenv/config";
import express from "express";
import cookieParser from "cookie-parser";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import crypto from "node:crypto";
import { exec as execCb, execFile as execFileCb, execSync, spawn } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import fssync from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} from "@simplewebauthn/server";

const exec = promisify(execCb);
const execFile = promisify(execFileCb);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

const PORT = process.env.PORT || 8080;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const WORKDIR = process.env.WORKDIR || path.join(os.homedir(), "mcp-workspace");
const DATA_DIR = path.join(__dirname, "data");
const PASSWORD_FILE = path.join(DATA_DIR, "password.json");
const PASSKEY_FILE = path.join(DATA_DIR, "passkeys.json");
const MANUAL_CLIENTS_FILE = path.join(DATA_DIR, "manual-clients.json");
const TOKENS_DIR = path.join(DATA_DIR, "tokens");
const RP_ID = new URL(BASE_URL).hostname;
const GUI_DISPLAY_RAW = process.env.GUI_DISPLAY || ":99";
const GUI_DISPLAY = GUI_DISPLAY_RAW.startsWith(":") ? GUI_DISPLAY_RAW : `:${GUI_DISPLAY_RAW}`;

function validateBaseUrl(raw) {
  try {
    const u = new URL(raw);
    const host = u.hostname;
    const ipv4 = /^(?:\d{1,3}\.){3}\d{1,3}$/.test(host);
    const ipv6 = host.includes(":");
    if (u.protocol !== "https:" || ipv4 || ipv6 || host === "localhost" || !host.includes(".")) return false;
    return true;
  } catch { return false; }
}
if (!validateBaseUrl(BASE_URL)) {
  console.error("FATAL: BASE_URL 必须是可公网访问的 HTTPS 域名；不支持直接使用 IP 地址。");
  process.exit(1);
}

await fs.mkdir(WORKDIR, { recursive: true });
await fs.mkdir(DATA_DIR, { recursive: true });

// ============ GUI 操控（可选，取决于宿主机是否装了对应工具）============
// 只要机器上有 xdotool + scrot 就能用GUI操控；显示器来源有两种：
//   1) 这台机器已经有真实显示器在跑（比如VNC/Xvnc提供的桌面）——直接接上去用，不重复启动
//   2) 没有现成显示器，但装了Xvfb——自己起一个虚拟显示器
function hasBinary(name) {
  try {
    execSync(`command -v ${name}`, { stdio: "ignore" });
    return true;
  } catch { return false; }
}

function displayAlreadyRunning(display) {
  try {
    execSync(`xdotool getdisplaygeometry`, { stdio: "ignore", env: { ...process.env, DISPLAY: display } });
    return true;
  } catch { return false; }
}

const GUI_BINARIES = { xvfb: "Xvfb", xdotool: "xdotool", scrot: "scrot" };
const guiAvailable = {
  xvfb: hasBinary(GUI_BINARIES.xvfb),
  xdotool: hasBinary(GUI_BINARIES.xdotool),
  scrot: hasBinary(GUI_BINARIES.scrot),
};

let xvfbProcess = null;
let GUI_ENABLED = false;

if (guiAvailable.xdotool && guiAvailable.scrot) {
  if (displayAlreadyRunning(GUI_DISPLAY)) {
    // 已经有VNC/真实桌面之类的显示器在这个display号上跑着，直接接上去用
    GUI_ENABLED = true;
    console.log(`GUI操控已启用，接管现有显示器 ${GUI_DISPLAY}（检测到已有VNC/桌面在运行）`);
  } else if (guiAvailable.xvfb) {
    // 没有现成显示器，自己起一个虚拟的
    xvfbProcess = spawn("Xvfb", [GUI_DISPLAY, "-screen", "0", "1280x800x24"], { stdio: "ignore", detached: true });
    xvfbProcess.unref();
    await new Promise((r) => setTimeout(r, 800)); // 给Xvfb一点启动时间
    GUI_ENABLED = displayAlreadyRunning(GUI_DISPLAY);
    console.log(GUI_ENABLED ? `GUI操控已启用，虚拟显示器 ${GUI_DISPLAY} 启动成功` : "GUI操控未启用（Xvfb启动失败）");
  } else {
    console.log(`GUI操控未启用（display ${GUI_DISPLAY} 上没有现成显示器，也没装Xvfb来自建一个）`);
  }
} else {
  console.log("GUI操控未启用（缺少 xdotool/scrot，这台机器可能没有对应权限或未安装）");
}

function guiEnv() { return { ...process.env, DISPLAY: GUI_DISPLAY }; }
await fs.mkdir(TOKENS_DIR, { recursive: true });

// ============ 密码存储 ============
function hashPassword(plain, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.scryptSync(plain, salt, 64).toString("hex");
  return { salt, hash };
}
function verifyPassword(plain, { salt, hash }) {
  const check = crypto.scryptSync(plain, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(check, "hex"), Buffer.from(hash, "hex"));
}
async function loadPasswordRecord() {
  if (fssync.existsSync(PASSWORD_FILE)) return JSON.parse(await fs.readFile(PASSWORD_FILE, "utf8"));
  const initial = process.env.ADMIN_PASSWORD;
  if (!initial) { console.error("FATAL: 必须设置 ADMIN_PASSWORD"); process.exit(1); }
  const record = hashPassword(initial);
  await fs.writeFile(PASSWORD_FILE, JSON.stringify(record, null, 2));
  return record;
}
let passwordRecord = await loadPasswordRecord();
async function changePassword(oldPlain, newPlain) {
  if (!verifyPassword(oldPlain, passwordRecord)) return false;
  passwordRecord = hashPassword(newPlain);
  await fs.writeFile(PASSWORD_FILE, JSON.stringify(passwordRecord, null, 2));
  return true;
}

// ============ Passkey 存储（含 id/name，支持改名+删除）============
async function loadPasskeys() {
  if (fssync.existsSync(PASSKEY_FILE)) return JSON.parse(await fs.readFile(PASSKEY_FILE, "utf8"));
  return [];
}
async function savePasskeys(list) { await fs.writeFile(PASSKEY_FILE, JSON.stringify(list, null, 2)); }

// ============ Token 存储：永久有效，单独存文件 data/tokens/<token>.json ============
const tokenCache = new Map(); // token -> { client_id, name, createdAt }
async function loadAllTokensIntoCache() {
  const files = await fs.readdir(TOKENS_DIR).catch(() => []);
  for (const f of files) {
    if (!f.endsWith(".json")) continue;
    const token = f.slice(0, -5);
    try {
      const data = JSON.parse(await fs.readFile(path.join(TOKENS_DIR, f), "utf8"));
      tokenCache.set(token, data);
    } catch { /* 忽略损坏文件 */ }
  }
}
await loadAllTokensIntoCache();
async function saveToken(token, record) {
  tokenCache.set(token, record);
  await fs.writeFile(path.join(TOKENS_DIR, `${token}.json`), JSON.stringify(record, null, 2));
}
async function deleteToken(token) {
  tokenCache.delete(token);
  await fs.rm(path.join(TOKENS_DIR, `${token}.json`), { force: true });
}

// ============ 手动客户端存储（给ChatGPT等不支持DCR的用）============
async function loadManualClients() {
  if (fssync.existsSync(MANUAL_CLIENTS_FILE)) return JSON.parse(await fs.readFile(MANUAL_CLIENTS_FILE, "utf8"));
  return {};
}
async function saveManualClients(obj) { await fs.writeFile(MANUAL_CLIENTS_FILE, JSON.stringify(obj, null, 2)); }
let manualClients = await loadManualClients();

// ============ 工具函数 ============
function randomToken(bytes = 32) { return crypto.randomBytes(bytes).toString("base64url"); }
function verifyPkce(verifier, challenge) {
  const hash = crypto.createHash("sha256").update(verifier).digest("base64url");
  return hash === challenge;
}

const app = express();
app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use((req, res, next) => {
  if (BASE_URL.startsWith("https://") && req.headers["x-forwarded-proto"] === "http") {
    return res.redirect(301, BASE_URL + req.originalUrl);
  }
  next();
});

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 8, standardHeaders: true, legacyHeaders: false, message: { error: "尝试次数过多，请15分钟后再试" } });
const apiLimiter = rateLimit({ windowMs: 60 * 1000, max: 60 });
app.use(["/mcp", "/token"], apiLimiter);

// ============ 内存存储（DCR客户端/授权码/nonce/session/webauthn挑战）============
const dcrClients = new Map();    // client_id -> { redirect_uris }
const authCodes = new Map();
const loginNonces = new Map();
const adminSessions = new Map();
const webauthnChallenges = new Map();

let lastActivity = Date.now();

function findClient(client_id) {
  if (dcrClients.has(client_id)) return { ...dcrClients.get(client_id), public: true };
  if (manualClients[client_id]) return { ...manualClients[client_id], public: false };
  return null;
}

// ============ Admin Session ============
const SESSION_COOKIE = "admin_session";
function createAdminSession(res) {
  const sid = randomToken(32);
  adminSessions.set(sid, { expiresAt: Date.now() + 7 * 24 * 3600_000 });
  res.cookie(SESSION_COOKIE, sid, { httpOnly: true, secure: BASE_URL.startsWith("https://"), sameSite: "lax", maxAge: 7 * 24 * 3600_000 });
}
function hasAdminSession(req) {
  const sid = req.cookies?.[SESSION_COOKIE];
  const entry = sid && adminSessions.get(sid);
  return !!(entry && entry.expiresAt > Date.now());
}
function requireAdminSession(req, res, next) {
  if (!hasAdminSession(req)) {
    return res.redirect("/login" + (req.originalUrl !== "/login" ? `?next=${encodeURIComponent(req.originalUrl)}` : ""));
  }
  next();
}

// ============ 奶油黄柔和UI ============
const THEME = {
  bgGrad: "linear-gradient(135deg, #FFFDF6 0%, #FFF3D9 100%)",
  cardBg: "#FFFFFF",
  cardShadow: "0 8px 30px rgba(199,155,58,0.14)",
  accent: "#C9962E",
  accentHover: "#B3831F",
  accentSoft: "#FBF0D9",
  accentSoftHover: "#F5E5BE",
  text: "#3A2F1E",
  textMuted: "#9C8C64",
  border: "#F0E3C0",
  danger: "#D9455F",
  dangerSoft: "#FDEEF0",
  ok: "#2FA06A",
};

const PAGE_I18N = {
  "登录":"Sign in", "输入密码":"Enter password", "登录":"Sign in", "或":"or", "使用 Passkey 登录":"Sign in with Passkey",
  "授权":"Authorize", "确认授权":"Authorize", "输入密码":"Enter password", "使用 Passkey 授权":"Authorize with Passkey",
  "JMCP 控制台":"JMCP Dashboard", "VPS 状态":"VPS Status", "连接概览":"Connection Overview", "已授权的连接":"Authorized Connections",
  "工作区":"Workspace", "修改密码":"Change Password", "Passkey 管理":"Passkey Management", "ChatGPT / 手动客户端接入":"ChatGPT / Manual Client",
  "CPU":"CPU", "内存":"Memory", "磁盘":"Disk", "工作区路径":"Workspace path", "已授权连接数":"Authorized connections",
  "已注册 Passkey":"Registered Passkeys", "GUI操控":"GUI control", "清空工作区":"Clear workspace",
  "Agent执行命令/读写文件的默认目录，文件不会自动删除，需要验证身份才能清空":"Default directory for Agent commands and file operations. Files are not deleted automatically; identity verification is required to clear it.",
  "输入密码确认":"Enter password to confirm", "用密码确认删除":"Confirm deletion with password", "用 Passkey 确认删除":"Confirm deletion with Passkey",
  "旧密码":"Old password", "新密码（至少8位）":"New password (at least 8 characters)", "修改":"Change",
  "添加新 Passkey":"Add Passkey", "ChatGPT等不支持自动注册的平台，用这里生成的 Client ID / Secret 手动配置":"For ChatGPT and other platforms without automatic client registration, generate a Client ID / Secret here for manual configuration.",
  "名称，比如 ChatGPT":"Name, e.g. ChatGPT", "回调URL（在对方平台OAuth设置里能看到）":"Callback URL (shown in the platform's OAuth settings)", "生成":"Generate",
  "退出登录":"Sign out", "暂无已授权的连接":"No authorized connections", "还没有注册 Passkey":"No Passkeys registered",
  "还没有为 ChatGPT 等生成手动客户端":"No manual clients have been created for ChatGPT or similar clients",
  "未命名连接":"Unnamed connection", "删除":"Delete", "添加于":"Added", "授权于":"Authorized",
  "在前面补上这个站点的完整网址即可，出于安全考虑这里不直接显示域名":"Prefix these paths with this site's full URL. The domain is intentionally not displayed here for security.",
  "已启用":"Enabled", "未启用（缺组件或无权限）":"Disabled (missing components or permission)",
  "或":"or", "必须使用 PKCE S256":"PKCE S256 is required", "未知的 client_id":"Unknown client_id",
  "会话已过期，请重新发起授权":"Session expired. Please start authorization again.", "密码错误":"Incorrect password",
  "会话已过期，请重新发起授权":"Session expired. Please start authorization again.",
};
const PAGE_I18N_EN = Object.fromEntries(Object.entries(PAGE_I18N).map(([zh,en]) => [en,zh]));

function languageScript() {
  return `<div class="lang-switch" aria-label="Language"><button type="button" onclick="setLanguage('zh')">中文</button><button type="button" onclick="setLanguage('en')">English</button></div>
<script>
(function(){
  const ZH=${JSON.stringify(PAGE_I18N)};
  const EN=${JSON.stringify(PAGE_I18N_EN)};
  function dict(lang){ return lang==='en' ? ZH : EN; }
  function replaceText(root, lang){
    const map=dict(lang);
    const walker=document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes=[]; while(walker.nextNode()) nodes.push(walker.currentNode);
    for(const n of nodes){
      const t=n.nodeValue.trim(); if(!t) continue;
      if(map[t]!==undefined) n.nodeValue=n.nodeValue.replace(t,map[t]);
      else if(lang==='en' && /^授权于 /.test(t)) n.nodeValue=n.nodeValue.replace(/^授权于 /,'Authorized ');
      else if(lang==='en' && /^添加于 /.test(t)) n.nodeValue=n.nodeValue.replace(/^添加于 /,'Added ');
      else if(lang==='zh' && /^Authorized /.test(t)) n.nodeValue=n.nodeValue.replace(/^Authorized /,'授权于 ');
      else if(lang==='zh' && /^Added /.test(t)) n.nodeValue=n.nodeValue.replace(/^Added /,'添加于 ');
      else if(lang==='en' && t==='❌ 未启用（缺组件或无权限）') n.nodeValue='❌ Disabled (missing components or permission)';
      else if(lang==='zh' && t==='❌ Disabled (missing components or permission)') n.nodeValue='❌ 未启用（缺组件或无权限）';
    }
    document.documentElement.lang=lang==='en'?'en':'zh-CN';
    document.title=lang==='en'?'JMCP':'JMCP';
  }
  window.setLanguage=function(lang){ localStorage.setItem('jmcp-language',lang); replaceText(document.body,lang); updateLanguageUI(lang); if(window.renderStats) window.renderStats(); };
  function updateLanguageUI(lang){ document.querySelectorAll('.lang-switch button').forEach(b=>b.classList.toggle('active', (lang==='en'&&b.textContent==='English') || (lang==='zh'&&b.textContent==='中文'))); }
  window.addEventListener('DOMContentLoaded',()=>{ const lang=localStorage.getItem('jmcp-language')||'zh'; if(lang==='en') replaceText(document.body,'en'); updateLanguageUI(lang); });
})();
</script>`;
}

function pageShell({ title, headerLeft, body }) {
  return `<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1" />
<title>${title}</title>
<style>
  * { box-sizing: border-box; }
  body {
    margin: 0; min-height: 100vh; display: flex; align-items: center; justify-content: center;
    background: ${THEME.bgGrad};
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
    color: ${THEME.text}; position: relative;
  }
  .header-left { position: absolute; top: 24px; left: 28px; font-size: 18px; font-weight: 700; color: ${THEME.accent}; }
  .card { background: ${THEME.cardBg}; border-radius: 24px; padding: 40px 36px; box-shadow: ${THEME.cardShadow}; width: 100%; max-width: 380px; }
  label { display:block; font-size: 13px; font-weight: 600; color: ${THEME.textMuted}; margin: 18px 0 6px; }
  input {
    width: 100%; padding: 12px 14px; border-radius: 12px; border: 1.5px solid ${THEME.border};
    font-size: 15px; outline: none; transition: border-color .15s; background: #FFFEFA;
  }
  input:focus { border-color: ${THEME.accent}; }
  button {
    width: 100%; padding: 12px; margin-top: 22px; border: none; border-radius: 12px;
    background: ${THEME.accent}; color: #fff; font-size: 15px; font-weight: 600; cursor: pointer; transition: background .15s;
  }
  button:hover { background: ${THEME.accentHover}; }
  button.secondary { background: ${THEME.accentSoft}; color: ${THEME.accent}; margin-top: 10px; }
  button.secondary:hover { background: ${THEME.accentSoftHover}; }
  .msg { text-align: center; font-size: 13px; margin-top: 14px; min-height: 18px; }
  .msg.error { color: ${THEME.danger}; }
  .msg.ok { color: ${THEME.ok}; }
  .divider { text-align:center; color:${THEME.textMuted}; font-size:12px; margin: 18px 0; }
  a { color: ${THEME.accent}; }
  .lang-switch { position:fixed; top:18px; right:20px; z-index:10; display:flex; gap:4px; }
  .lang-switch button { width:auto; margin:0; padding:6px 9px; font-size:12px; border-radius:9px; background:${THEME.accentSoft}; color:${THEME.accent}; }
  .lang-switch button.active { background:${THEME.accent}; color:#fff; }
</style>
</head><body>
${headerLeft ? `<div class="header-left">${headerLeft}</div>` : ""}
${languageScript()}
<div class="card">${body}</div>
</body></html>`;
}

function dashboardShell(body) {
  return `<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1" />
<title>JMCP Dashboard</title>
<style>
  * { box-sizing: border-box; }
  body {
    margin: 0; background: ${THEME.bgGrad}; background-attachment: fixed;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
    color: ${THEME.text}; padding: 24px 16px 60px;
  }
  .wrap { max-width: 640px; margin: 0 auto; }
  h1 { font-size: 20px; margin: 8px 0 24px; color: ${THEME.accent}; font-weight: 700; }
  .section { background:${THEME.cardBg}; border-radius:18px; margin-bottom:16px; box-shadow: ${THEME.cardShadow}; overflow: hidden; }
  .section-header {
    display:flex; justify-content:space-between; align-items:center; padding:16px 20px; cursor:pointer; user-select:none;
  }
  .section-header h2 { font-size:15px; margin:0; color:${THEME.accent}; font-weight:700; }
  .tri { font-size:11px; color:${THEME.accent}; transition: transform .2s; display:inline-block; }
  .section.collapsed .tri { transform: rotate(180deg); }
  .section-body { padding: 0 20px 20px; }
  .section.collapsed .section-body { display: none; }
  .row { display:flex; justify-content:space-between; align-items:center; padding:8px 0; border-bottom:1px solid ${THEME.border}; font-size:14px; gap:10px; }
  .row:last-child { border-bottom:none; }
  .muted { color:${THEME.textMuted}; font-size:12px; }
  input { width:100%; padding:10px 12px; border-radius:10px; border:1.5px solid ${THEME.border}; font-size:14px; margin:6px 0; background:#FFFEFA; }
  button { padding:9px 16px; border:none; border-radius:10px; background:${THEME.accent}; color:#fff; font-size:13px; font-weight:600; cursor:pointer; white-space:nowrap; }
  button.danger { background:${THEME.dangerSoft}; color:${THEME.danger}; }
  button.ghost { background:${THEME.accentSoft}; color:${THEME.accent}; }
  button.small { padding:6px 10px; font-size:12px; }
  .msg { font-size:13px; margin-top:8px; min-height:16px; }
  .msg.error { color:${THEME.danger}; } .msg.ok { color:${THEME.ok}; }
  code { background:${THEME.accentSoft}; padding:2px 6px; border-radius:6px; font-size:12px; word-break:break-all; }
  .statgrid { display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; }
  .stat { background:${THEME.accentSoft}; border-radius:14px; padding:12px; text-align:center; }
  .stat .val { font-size:18px; font-weight:700; color:${THEME.accent}; }
  .stat .lbl { font-size:11px; color:${THEME.textMuted}; margin-top:2px; }
  .bar { height:6px; border-radius:4px; background:${THEME.border}; overflow:hidden; margin-top:6px; }
  .bar-fill { height:100%; background:${THEME.accent}; }
  .itemname { font-weight:600; }
  .itemname input { display:none; }
  .itemname.editing span { display:none; }
  .itemname.editing input { display:block; }
  .topbar { display:flex; justify-content:space-between; align-items:center; gap:12px; }
  .topbar .lang-switch { position:static; }
  .lang-switch { display:flex; gap:4px; }
  .lang-switch button { padding:5px 9px; border:1px solid ${THEME.border}; border-radius:8px; background:${THEME.accentSoft}; color:${THEME.accent}; cursor:pointer; font-size:12px; }
  .lang-switch button.active { background:${THEME.accent}; color:#fff; }
</style>
</head><body><div class="wrap">
<div class="topbar"><h1>JMCP 控制台</h1>${languageScript()}</div>
${body}
<script>
  function toggleSection(id) {
    document.getElementById(id).classList.toggle('collapsed');
  }
</script>
</div></body></html>`;
}

function section(id, title, bodyHtml, { defaultOpen = false } = {}) {
  return `
    <div class="section${defaultOpen ? "" : " collapsed"}" id="${id}">
      <div class="section-header" onclick="toggleSection('${id}')">
        <h2>${title}</h2>
        <span class="tri">▲</span>
      </div>
      <div class="section-body">${bodyHtml}</div>
    </div>`;
}

// ============ VPS 状态 ============
function cpuSnapshot() {
  return os.cpus().map((c) => ({ ...c.times }));
}
function cpuUsagePercent(a, b) {
  let idleDiff = 0, totalDiff = 0;
  for (let i = 0; i < a.length; i++) {
    const ta = Object.values(a[i]).reduce((s, v) => s + v, 0);
    const tb = Object.values(b[i]).reduce((s, v) => s + v, 0);
    idleDiff += b[i].idle - a[i].idle;
    totalDiff += tb - ta;
  }
  return totalDiff === 0 ? 0 : Math.round((1 - idleDiff / totalDiff) * 1000) / 10;
}
async function getSystemStats() {
  const snap1 = cpuSnapshot();
  await new Promise((r) => setTimeout(r, 150));
  const snap2 = cpuSnapshot();
  const cpuPercent = cpuUsagePercent(snap1, snap2);

  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = totalMem - freeMem;

  let disk = null;
  try {
    const stat = await fs.statfs(WORKDIR);
    const totalDisk = stat.blocks * stat.bsize;
    const freeDisk = stat.bavail * stat.bsize;
    disk = { total: totalDisk, free: freeDisk, used: totalDisk - freeDisk };
  } catch { /* statfs 不支持时忽略 */ }

  return {
    cpu: { percent: cpuPercent, cores: os.cpus().length, load1: os.loadavg()[0] },
    mem: { total: totalMem, free: freeMem, used: usedMem, percent: Math.round((usedMem / totalMem) * 1000) / 10 },
    disk: disk ? { ...disk, percent: Math.round((disk.used / disk.total) * 1000) / 10 } : null,
    uptime: os.uptime(),
  };
}
function fmtBytes(n) {
  if (n == null) return "-";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0; let v = n;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(1)} ${units[i]}`;
}

app.get("/api/system-stats", requireAdminSession, async (req, res) => {
  res.json(await getSystemStats());
});

// ============ WebAuthn 通用JS片段（登录页与授权页共用） ============
const WEBAUTHN_JS_HELPERS = `
  function b64urlToBuf(s) {
    s = s.replace(/-/g,'+').replace(/_/g,'/');
    while (s.length % 4) s += '=';
    const bin = atob(s); const buf = new Uint8Array(bin.length);
    for (let i=0;i<bin.length;i++) buf[i]=bin.charCodeAt(i);
    return buf;
  }
  function bufToB64url(buf) {
    const bytes = new Uint8Array(buf); let bin='';
    for (const b of bytes) bin += String.fromCharCode(b);
    return btoa(bin).replace(/\\+/g,'-').replace(/\\//g,'_').replace(/=+$/,'');
  }
  async function doPasskeyLogin() {
    const optRes = await fetch('/webauthn/login/options');
    if (!optRes.ok) { const d = await optRes.json(); throw new Error(d.error); }
    const options = await optRes.json();
    options.challenge = b64urlToBuf(options.challenge);
    options.allowCredentials = (options.allowCredentials||[]).map(c => ({...c, id: b64urlToBuf(c.id)}));
    const cred = await navigator.credentials.get({ publicKey: options });
    const payload = {
      id: cred.id, rawId: bufToB64url(cred.rawId), type: cred.type,
      response: {
        clientDataJSON: bufToB64url(cred.response.clientDataJSON),
        authenticatorData: bufToB64url(cred.response.authenticatorData),
        signature: bufToB64url(cred.response.signature),
        userHandle: cred.response.userHandle ? bufToB64url(cred.response.userHandle) : undefined,
      },
    };
    const verifyRes = await fetch('/webauthn/login/verify', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload),
    });
    if (!verifyRes.ok) { const d = await verifyRes.json(); throw new Error(d.error); }
  }
`;

// ============ Passkey 注册（需登录）============
app.get("/webauthn/register/options", requireAdminSession, async (req, res) => {
  const passkeys = await loadPasskeys();
  const options = await generateRegistrationOptions({
    rpName: "JMCP", rpID: RP_ID, userName: "admin", attestationType: "none",
    excludeCredentials: passkeys.map((p) => ({ id: p.credentialId, transports: p.transports })),
    authenticatorSelection: { residentKey: "preferred", userVerification: "preferred" },
  });
  webauthnChallenges.set("register", { challenge: options.challenge, expiresAt: Date.now() + 5 * 60_000 });
  res.json(options);
});

app.post("/webauthn/register/verify", requireAdminSession, async (req, res) => {
  const entry = webauthnChallenges.get("register");
  if (!entry || entry.expiresAt < Date.now()) return res.status(400).json({ error: "验证已过期，重试一次" });
  try {
    const verification = await verifyRegistrationResponse({
      response: req.body, expectedChallenge: entry.challenge, expectedOrigin: BASE_URL, expectedRPID: RP_ID,
    });
    if (!verification.verified) return res.status(400).json({ error: "验证失败" });
    const { credential } = verification.registrationInfo;
    const passkeys = await loadPasskeys();
    passkeys.push({
      id: randomToken(8),
      name: `Passkey ${passkeys.length + 1}`,
      credentialId: credential.id,
      publicKey: Buffer.from(credential.publicKey).toString("base64url"),
      counter: credential.counter,
      transports: credential.transports || [],
      createdAt: Date.now(),
    });
    await savePasskeys(passkeys);
    webauthnChallenges.delete("register");
    res.json({ ok: true });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// ============ Passkey 登录（授权页/登录页共用）============
app.get("/webauthn/login/options", async (req, res) => {
  const passkeys = await loadPasskeys();
  if (passkeys.length === 0) return res.status(400).json({ error: "还没有注册过 Passkey" });
  const options = await generateAuthenticationOptions({
    rpID: RP_ID, userVerification: "preferred",
    allowCredentials: passkeys.map((p) => ({ id: p.credentialId, transports: p.transports })),
  });
  webauthnChallenges.set("login", { challenge: options.challenge, expiresAt: Date.now() + 5 * 60_000 });
  res.json(options);
});

app.post("/webauthn/login/verify", loginLimiter, async (req, res) => {
  const entry = webauthnChallenges.get("login");
  if (!entry || entry.expiresAt < Date.now()) return res.status(400).json({ error: "验证已过期，重试一次" });
  const passkeys = await loadPasskeys();
  const match = passkeys.find((p) => p.credentialId === req.body.id);
  if (!match) return res.status(400).json({ error: "未知的 Passkey" });
  try {
    const verification = await verifyAuthenticationResponse({
      response: req.body, expectedChallenge: entry.challenge, expectedOrigin: BASE_URL, expectedRPID: RP_ID,
      credential: { id: match.credentialId, publicKey: Buffer.from(match.publicKey, "base64url"), counter: match.counter, transports: match.transports },
    });
    if (!verification.verified) return res.status(400).json({ error: "验证失败" });
    match.counter = verification.authenticationInfo.newCounter;
    await savePasskeys(passkeys);
    webauthnChallenges.delete("login");
    createAdminSession(res);
    res.json({ ok: true });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// ============ 二次验证（Passkey）——仅用于确认破坏性操作，如清空工作区 ============
app.get("/webauthn/stepup/options", requireAdminSession, async (req, res) => {
  const passkeys = await loadPasskeys();
  if (passkeys.length === 0) return res.status(400).json({ error: "还没有注册过 Passkey，请用密码确认" });
  const options = await generateAuthenticationOptions({
    rpID: RP_ID, userVerification: "preferred",
    allowCredentials: passkeys.map((p) => ({ id: p.credentialId, transports: p.transports })),
  });
  webauthnChallenges.set("stepup", { challenge: options.challenge, expiresAt: Date.now() + 2 * 60_000 });
  res.json(options);
});

app.post("/webauthn/stepup/verify", requireAdminSession, loginLimiter, async (req, res) => {
  const entry = webauthnChallenges.get("stepup");
  if (!entry || entry.expiresAt < Date.now()) return res.status(400).json({ error: "验证已过期，重试一次" });
  const passkeys = await loadPasskeys();
  const match = passkeys.find((p) => p.credentialId === req.body.id);
  if (!match) return res.status(400).json({ error: "未知的 Passkey" });
  try {
    const verification = await verifyAuthenticationResponse({
      response: req.body, expectedChallenge: entry.challenge, expectedOrigin: BASE_URL, expectedRPID: RP_ID,
      credential: { id: match.credentialId, publicKey: Buffer.from(match.publicKey, "base64url"), counter: match.counter, transports: match.transports },
    });
    if (!verification.verified) return res.status(400).json({ error: "验证失败" });
    match.counter = verification.authenticationInfo.newCounter;
    await savePasskeys(passkeys);
    webauthnChallenges.delete("stepup");
    const stepupToken = randomToken(24);
    const sid = req.cookies?.[SESSION_COOKIE];
    stepupTokens.set(stepupToken, { sid, expiresAt: Date.now() + 60_000 });
    res.json({ ok: true, stepup_token: stepupToken });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.post("/api/rename-passkey", requireAdminSession, async (req, res) => {
  const { id, name } = req.body || {};
  const passkeys = await loadPasskeys();
  const p = passkeys.find((x) => x.id === id);
  if (!p) return res.status(404).json({ error: "未找到" });
  p.name = (name || "").slice(0, 50) || p.name;
  await savePasskeys(passkeys);
  res.json({ ok: true });
});

app.post("/api/delete-passkey", requireAdminSession, async (req, res) => {
  const { id } = req.body || {};
  const passkeys = await loadPasskeys();
  const next = passkeys.filter((x) => x.id !== id);
  await savePasskeys(next);
  res.json({ ok: true });
});

// ============ 登录页 ============
app.get("/login", (req, res) => {
  const next = req.query.next || "/dashboard";
  res.send(pageShell({
    title: "登录", headerLeft: "登录",
    body: `
      <form id="pwForm">
        <label>输入密码</label>
        <input type="password" id="password" autofocus />
        <button type="submit">登录</button>
      </form>
      <div class="divider">或</div>
      <button type="button" class="secondary" id="passkeyBtn">使用 Passkey 登录</button>
      <div class="msg" id="msg"></div>
      <script>
        ${WEBAUTHN_JS_HELPERS}
        const next = ${JSON.stringify(next)};
        document.getElementById('pwForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const res = await fetch('/login', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ password: document.getElementById('password').value }) });
          const msg = document.getElementById('msg');
          if (res.ok) { location.href = next; }
          else { const d = await res.json(); msg.textContent = '❌ ' + d.error; msg.className = 'msg error'; }
        });
        document.getElementById('passkeyBtn').addEventListener('click', async () => {
          const msg = document.getElementById('msg');
          try { await doPasskeyLogin(); location.href = next; }
          catch (err) { msg.textContent = '❌ ' + err.message; msg.className='msg error'; }
        });
      </script>
    `,
  }));
});

app.post("/login", loginLimiter, (req, res) => {
  const { password } = req.body || {};
  if (!verifyPassword(password || "", passwordRecord)) return res.status(401).json({ error: "密码错误" });
  createAdminSession(res);
  res.json({ ok: true });
});

app.post("/logout", (req, res) => {
  const sid = req.cookies?.[SESSION_COOKIE];
  if (sid) adminSessions.delete(sid);
  res.clearCookie(SESSION_COOKIE);
  res.redirect("/login");
});

// ============ Dashboard ============
app.get("/dashboard", requireAdminSession, async (req, res) => {
  const passkeys = await loadPasskeys();
  const tokenRows = [...tokenCache.entries()].map(([token, v]) => `
    <div class="row">
      <span class="itemname" id="tokname-${token}">
        <span onclick="startRename('tokname-${token}')">${v.name || "未命名连接"}</span>
        <input value="${(v.name || "").replace(/"/g, "&quot;")}" onkeydown="if(event.key==='Enter')renameToken('${token}','tokname-${token}')" onblur="renameToken('${token}','tokname-${token}')" />
        <br/><span class="muted">授权于 ${new Date(v.createdAt).toLocaleString("zh-CN")}</span>
      </span>
      <button class="danger small" onclick="revokeToken('${token}')">删除</button>
    </div>`).join("") || `<p class="muted">暂无已授权的连接</p>`;

  const passkeyRows = passkeys.map((p) => `
    <div class="row">
      <span class="itemname" id="pkname-${p.id}">
        <span onclick="startRename('pkname-${p.id}')">${p.name}</span>
        <input value="${p.name.replace(/"/g, "&quot;")}" onkeydown="if(event.key==='Enter')renamePasskey('${p.id}','pkname-${p.id}')" onblur="renamePasskey('${p.id}','pkname-${p.id}')" />
        <br/><span class="muted">添加于 ${new Date(p.createdAt).toLocaleString("zh-CN")}</span>
      </span>
      <button class="danger small" onclick="deletePasskey('${p.id}')">删除</button>
    </div>`).join("") || `<p class="muted">还没有注册 Passkey</p>`;

  const manualClientRows = Object.entries(manualClients).map(([cid, c]) => `
    <div class="row">
      <span><b>${c.name}</b><br/><span class="muted">Client ID: <code>${cid}</code></span></span>
      <button class="danger small" onclick="deleteManualClient('${cid}')">删除</button>
    </div>`).join("") || `<p class="muted">还没有为 ChatGPT 等生成手动客户端</p>`;

  res.send(dashboardShell(`
    ${section("sec-stats", "VPS 状态", `
      <div class="statgrid" id="statgrid">
        <div class="stat"><div class="val" id="cpuVal">-</div><div class="lbl">CPU</div></div>
        <div class="stat"><div class="val" id="memVal">-</div><div class="lbl">内存</div></div>
        <div class="stat"><div class="val" id="diskVal">-</div><div class="lbl">磁盘</div></div>
      </div>
      <div class="muted" id="statDetail" style="margin-top:10px"></div>
    `, { defaultOpen: true })}

    ${section("sec-status", "连接概览", `
      <div class="row"><span>工作区路径</span><span class="muted">${WORKDIR}</span></div>
      <div class="row"><span>已授权连接数</span><span>${tokenCache.size}</span></div>
      <div class="row"><span>已注册 Passkey</span><span>${passkeys.length}</span></div>
      <div class="row"><span>GUI操控</span><span>${GUI_ENABLED ? "✅ 已启用" : "❌ 未启用（缺组件或无权限）"}</span></div>
    `, { defaultOpen: true })}

    ${section("sec-tokens", "已授权的连接", tokenRows)}

    ${section("sec-workspace", "工作区", `
      <p class="muted">Agent执行命令/读写文件的默认目录，文件不会自动删除，需要验证身份才能清空</p>
      <button class="ghost" onclick="showCleanConfirm()" id="cleanTriggerBtn">清空工作区</button>
      <div id="cleanConfirmBox" style="display:none;margin-top:10px">
        <input type="password" id="cleanPw" placeholder="输入密码确认" />
        <button class="danger" onclick="cleanWorkspaceByPassword()">用密码确认删除</button>
        <button class="ghost" onclick="cleanWorkspaceByPasskey()" style="margin-top:8px">用 Passkey 确认删除</button>
      </div>
      <div class="msg" id="wsMsg"></div>
    `)}

    ${section("sec-password", "修改密码", `
      <input type="password" id="oldPw" placeholder="旧密码" />
      <input type="password" id="newPw" placeholder="新密码（至少8位）" />
      <button onclick="changePw()">修改</button>
      <div class="msg" id="pwMsg"></div>
    `)}

    ${section("sec-passkeys", "Passkey 管理", `
      <button class="ghost" onclick="registerPasskey()">添加新 Passkey</button>
      <div class="msg" id="pkMsg" style="margin-bottom:10px"></div>
      ${passkeyRows}
    `)}

    ${section("sec-chatgpt", "ChatGPT / 手动客户端接入", `
      <p class="muted">ChatGPT等不支持自动注册的平台，用这里生成的 Client ID / Secret 手动配置</p>
      <input id="cgName" placeholder="名称，比如 ChatGPT" />
      <input id="cgRedirect" placeholder="回调URL（在对方平台OAuth设置里能看到）" />
      <button onclick="createManualClient()">生成</button>
      <div class="msg" id="cgMsg"></div>
      <div style="margin-top:12px">${manualClientRows}</div>
      <p class="muted" style="margin-top:12px">
        Authorize URL: <code>/authorize</code><br/>
        Token URL: <code>/token</code><br/>
        （在前面补上这个站点的完整网址即可，出于安全考虑这里不直接显示域名）
      </p>
    `)}

    <div class="section"><div class="section-body" style="padding-top:20px">
      <button class="danger" onclick="logout()">退出登录</button>
    </div></div>

    <script>
      function bufToB64url(buf) { const bytes=new Uint8Array(buf);let bin='';for(const b of bytes)bin+=String.fromCharCode(b);return btoa(bin).replace(/\\+/g,'-').replace(/\\//g,'_').replace(/=+$/,''); }
      function b64urlToBuf(s) { s=s.replace(/-/g,'+').replace(/_/g,'/'); while(s.length%4)s+='='; const bin=atob(s); const buf=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++)buf[i]=bin.charCodeAt(i); return buf; }

      function startRename(id) { document.getElementById(id).classList.add('editing'); document.getElementById(id).querySelector('input').focus(); }

      async function revokeToken(token) { await fetch('/api/revoke-token', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ token }) }); location.reload(); }
      async function renameToken(token, elId) {
        const val = document.getElementById(elId).querySelector('input').value;
        await fetch('/api/rename-token', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ token, name: val }) });
        location.reload();
      }
      async function deletePasskey(id) { await fetch('/api/delete-passkey', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id }) }); location.reload(); }
      async function renamePasskey(id, elId) {
        const val = document.getElementById(elId).querySelector('input').value;
        await fetch('/api/rename-passkey', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id, name: val }) });
        location.reload();
      }
      async function deleteManualClient(cid) { await fetch('/api/delete-manual-client', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ client_id: cid }) }); location.reload(); }
      async function createManualClient() {
        const el = document.getElementById('cgMsg');
        const name = document.getElementById('cgName').value;
        const redirect_uri = document.getElementById('cgRedirect').value;
        const r = await fetch('/api/create-manual-client', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ name, redirect_uri }) });
        const d = await r.json();
        if (d.ok) {
          el.className = 'msg ok';
          el.innerHTML = '✅ 已生成，client_secret 只显示这一次，务必现在复制：<br/><code>' + d.client_id + '</code><br/><code>' + d.client_secret + '</code>';
        } else { el.textContent = '❌ ' + d.error; el.className = 'msg error'; }
      }

      function showCleanConfirm() {
        document.getElementById('cleanConfirmBox').style.display = 'block';
        document.getElementById('cleanTriggerBtn').style.display = 'none';
      }
      async function cleanWorkspaceByPassword() {
        const el = document.getElementById('wsMsg');
        const password = document.getElementById('cleanPw').value;
        const r = await fetch('/api/clean-workspace', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ password }) });
        const d = await r.json();
        el.textContent = d.ok ? '✅ 已清空' : '❌ ' + d.error;
        el.className = 'msg ' + (d.ok ? 'ok' : 'error');
        if (d.ok) setTimeout(() => location.reload(), 800);
      }
      async function cleanWorkspaceByPasskey() {
        const el = document.getElementById('wsMsg');
        try {
          const optRes = await fetch('/webauthn/stepup/options');
          if (!optRes.ok) { const d = await optRes.json(); throw new Error(d.error); }
          const options = await optRes.json();
          options.challenge = b64urlToBuf(options.challenge);
          options.allowCredentials = (options.allowCredentials||[]).map(c => ({...c, id: b64urlToBuf(c.id)}));
          const cred = await navigator.credentials.get({ publicKey: options });
          const payload = {
            id: cred.id, rawId: bufToB64url(cred.rawId), type: cred.type,
            response: {
              clientDataJSON: bufToB64url(cred.response.clientDataJSON),
              authenticatorData: bufToB64url(cred.response.authenticatorData),
              signature: bufToB64url(cred.response.signature),
              userHandle: cred.response.userHandle ? bufToB64url(cred.response.userHandle) : undefined,
            },
          };
          const verifyRes = await fetch('/webauthn/stepup/verify', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
          const verifyData = await verifyRes.json();
          if (!verifyRes.ok) throw new Error(verifyData.error);
          const stepup_token = verifyData.stepup_token;
          const r = await fetch('/api/clean-workspace', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ stepup_token }) });
          const d = await r.json();
          el.textContent = d.ok ? '✅ 已清空' : '❌ ' + d.error;
          el.className = 'msg ' + (d.ok ? 'ok' : 'error');
          if (d.ok) setTimeout(() => location.reload(), 800);
        } catch (err) { el.textContent = '❌ ' + err.message; el.className = 'msg error'; }
      }
      async function changePw() {
        const r = await fetch('/api/change-password', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ old_password: document.getElementById('oldPw').value, new_password: document.getElementById('newPw').value }) });
        const d = await r.json();
        const el = document.getElementById('pwMsg');
        el.textContent = d.ok ? '✅ 修改成功' : '❌ ' + d.error;
        el.className = 'msg ' + (d.ok ? 'ok' : 'error');
      }
      async function registerPasskey() {
        const el = document.getElementById('pkMsg');
        try {
          const optRes = await fetch('/webauthn/register/options');
          const options = await optRes.json();
          options.challenge = b64urlToBuf(options.challenge);
          options.user.id = b64urlToBuf(options.user.id);
          if (options.excludeCredentials) options.excludeCredentials = options.excludeCredentials.map(c => ({...c, id: b64urlToBuf(c.id)}));
          const cred = await navigator.credentials.create({ publicKey: options });
          const payload = { id: cred.id, rawId: bufToB64url(cred.rawId), type: cred.type, response: { clientDataJSON: bufToB64url(cred.response.clientDataJSON), attestationObject: bufToB64url(cred.response.attestationObject), transports: cred.response.getTransports ? cred.response.getTransports() : [] } };
          const verifyRes = await fetch('/webauthn/register/verify', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
          const d = await verifyRes.json();
          if (d.ok) location.reload();
          else { el.textContent = '❌ ' + d.error; el.className = 'msg error'; }
        } catch (err) { el.textContent = '❌ ' + err.message; el.className = 'msg error'; }
      }
      function logout() { fetch('/logout', { method:'POST' }).then(() => location.href = '/login'); }

      let latestStats = null;
      window.renderStats = function() {
        if (!latestStats) return;
        const d = latestStats;
        const en = localStorage.getItem('jmcp-language') === 'en';
        document.getElementById('statDetail').innerHTML = en
          ? 'CPU: ' + d.cpu.cores + ' cores · Load ' + d.cpu.load1.toFixed(2) + '<br/>' +
            'Memory: ' + formatBytes(d.mem.used) + ' / ' + formatBytes(d.mem.total) + '<br/>' +
            (d.disk ? ('Disk: ' + formatBytes(d.disk.used) + ' / ' + formatBytes(d.disk.total) + '<br/>') : '') +
            'Uptime: ' + Math.floor(d.uptime / 3600) + ' hours'
          : 'CPU: ' + d.cpu.cores + '核 · 负载 ' + d.cpu.load1.toFixed(2) + '<br/>' +
            '内存: ' + formatBytes(d.mem.used) + ' / ' + formatBytes(d.mem.total) + '<br/>' +
            (d.disk ? ('磁盘: ' + formatBytes(d.disk.used) + ' / ' + formatBytes(d.disk.total) + '<br/>') : '') +
            '运行时间: ' + Math.floor(d.uptime / 3600) + ' 小时';
      };
      async function loadStats() {
        try {
          const r = await fetch('/api/system-stats');
          const d = await r.json();
          latestStats = d;
          document.getElementById('cpuVal').textContent = d.cpu.percent + '%';
          document.getElementById('memVal').textContent = d.mem.percent + '%';
          document.getElementById('diskVal').textContent = d.disk ? d.disk.percent + '%' : 'N/A';
          renderStats();
        } catch (e) {}
      }
      function formatBytes(n) {
        const units=['B','KB','MB','GB','TB']; let i=0; let v=n;
        while (v>=1024 && i<units.length-1) { v/=1024; i++; }
        return v.toFixed(1) + ' ' + units[i];
      }
      loadStats();
      setInterval(loadStats, 8000);
    </script>
  `));
});

app.post("/api/revoke-token", requireAdminSession, async (req, res) => { await deleteToken(req.body.token); res.json({ ok: true }); });
app.post("/api/rename-token", requireAdminSession, async (req, res) => {
  const { token, name } = req.body || {};
  const rec = tokenCache.get(token);
  if (!rec) return res.status(404).json({ error: "未找到" });
  rec.name = (name || "").slice(0, 50) || rec.name;
  await saveToken(token, rec);
  res.json({ ok: true });
});

app.post("/api/clean-workspace", requireAdminSession, loginLimiter, async (req, res) => {
  const { password, stepup_token } = req.body || {};
  let authorized = false;

  if (password) {
    authorized = verifyPassword(password, passwordRecord);
  } else if (stepup_token) {
    const entry = stepupTokens.get(stepup_token);
    const sid = req.cookies?.[SESSION_COOKIE];
    if (entry && entry.sid === sid && entry.expiresAt > Date.now()) {
      authorized = true;
      stepupTokens.delete(stepup_token); // 一次性
    }
  }

  if (!authorized) return res.status(401).json({ error: "密码不正确或Passkey验证已过期，未执行删除" });

  try { await cleanWorkspace(); res.json({ ok: true }); } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/change-password", requireAdminSession, async (req, res) => {
  const { old_password, new_password } = req.body || {};
  if (!old_password || !new_password) return res.status(400).json({ error: "缺少参数" });
  if (new_password.length < 8) return res.status(400).json({ error: "新密码至少8位" });
  const ok = await changePassword(old_password, new_password);
  res.json(ok ? { ok: true } : { error: "旧密码不正确" });
});

app.post("/api/create-manual-client", requireAdminSession, async (req, res) => {
  const { name, redirect_uri } = req.body || {};
  if (!name || !redirect_uri) return res.status(400).json({ error: "名称和回调URL都不能为空" });
  const client_id = randomToken(16);
  const client_secret = randomToken(32);
  manualClients[client_id] = { client_id, client_secret, name: name.slice(0, 50), redirect_uris: [redirect_uri] };
  await saveManualClients(manualClients);
  res.json({ ok: true, client_id, client_secret });
});

app.post("/api/delete-manual-client", requireAdminSession, async (req, res) => {
  delete manualClients[req.body.client_id];
  await saveManualClients(manualClients);
  res.json({ ok: true });
});

// ============ OAuth 元数据发现 ============
app.get("/.well-known/oauth-authorization-server", (req, res) => {
  res.json({
    issuer: BASE_URL,
    authorization_endpoint: `${BASE_URL}/authorize`,
    token_endpoint: `${BASE_URL}/token`,
    registration_endpoint: `${BASE_URL}/register`,
    revocation_endpoint: `${BASE_URL}/revoke`,
    response_types_supported: ["code"],
    grant_types_supported: ["authorization_code"],
    code_challenge_methods_supported: ["S256"],
    token_endpoint_auth_methods_supported: ["none", "client_secret_post", "client_secret_basic"],
  });
});

app.post("/register", (req, res) => {
  const client_id = randomToken(16);
  const redirect_uris = req.body.redirect_uris || [];
  dcrClients.set(client_id, { redirect_uris });
  res.status(201).json({ client_id, redirect_uris, token_endpoint_auth_method: "none" });
});

app.post("/revoke", async (req, res) => { await deleteToken(req.body.token); res.json({ ok: true }); });

// ============ 授权页（居中圆角卡片 + Passkey支持）============
app.get("/authorize", (req, res) => {
  const { client_id, redirect_uri, state, code_challenge, code_challenge_method } = req.query;
  const client = findClient(client_id);
  if (!client) return res.status(400).send("未知的 client_id");
  if (code_challenge_method !== "S256") return res.status(400).send("必须使用 PKCE S256");

  const nonce = randomToken(16);
  loginNonces.set(nonce, { client_id, redirect_uri, state, code_challenge, expiresAt: Date.now() + 5 * 60_000 });

  if (hasAdminSession(req)) {
    return res.send(pageShell({
      title: "授权", headerLeft: "授权",
      body: `
        <p style="text-align:center;color:${THEME.textMuted};font-size:14px;margin-top:0">${client.name || "Agent"} 请求连接到你的远程执行环境</p>
        <form method="POST" action="/authorize/confirm">
          <input type="hidden" name="nonce" value="${nonce}" />
          <button type="submit">确认授权</button>
        </form>
      `,
    }));
  }

  res.send(pageShell({
    title: "授权", headerLeft: "授权",
    body: `
      <form method="POST" action="/authorize/confirm" id="authForm">
        <input type="hidden" name="nonce" value="${nonce}" />
        <label>输入密码</label>
        <input type="password" name="password" autofocus />
        <button type="submit">授权</button>
      </form>
      <div class="divider">或</div>
      <button type="button" class="secondary" id="passkeyBtn">使用 Passkey 授权</button>
      <div class="msg" id="msg"></div>
      <script>
        ${WEBAUTHN_JS_HELPERS}
        document.getElementById('passkeyBtn').addEventListener('click', async () => {
          const msg = document.getElementById('msg');
          try {
            await doPasskeyLogin();
            document.getElementById('authForm').submit();
          } catch (err) { msg.textContent = '❌ ' + err.message; msg.className='msg error'; }
        });
      </script>
    `,
  }));
});

app.post("/authorize/confirm", loginLimiter, (req, res) => {
  const { nonce, password } = req.body;
  const entry = loginNonces.get(nonce);
  if (!entry || entry.expiresAt < Date.now()) return res.status(400).send("会话已过期，请重新发起授权");

  if (!hasAdminSession(req)) {
    if (!verifyPassword(password || "", passwordRecord)) return res.status(401).send("密码错误");
  }
  loginNonces.delete(nonce);

  const code = randomToken(24);
  authCodes.set(code, { client_id: entry.client_id, redirect_uri: entry.redirect_uri, code_challenge: entry.code_challenge, expiresAt: Date.now() + 60_000 });

  const redirectUrl = new URL(entry.redirect_uri);
  redirectUrl.searchParams.set("code", code);
  if (entry.state) redirectUrl.searchParams.set("state", entry.state);
  res.redirect(redirectUrl.toString());
});

// ============ Token 端点（支持 public/DCR 客户端 与 手动client_secret客户端）============
function extractClientSecret(req) {
  if (req.body?.client_secret) return req.body.client_secret;
  const auth = req.headers.authorization || "";
  if (auth.startsWith("Basic ")) {
    const decoded = Buffer.from(auth.slice(6), "base64").toString("utf8");
    const idx = decoded.indexOf(":");
    if (idx >= 0) return decoded.slice(idx + 1);
  }
  return null;
}

app.post("/token", async (req, res) => {
  const { grant_type, code, redirect_uri, code_verifier } = req.body;
  const client_id = req.body.client_id || (() => {
    const auth = req.headers.authorization || "";
    if (auth.startsWith("Basic ")) return Buffer.from(auth.slice(6), "base64").toString("utf8").split(":")[0];
    return undefined;
  })();

  if (grant_type !== "authorization_code") return res.status(400).json({ error: "unsupported_grant_type" });

  const client = findClient(client_id);
  if (!client) return res.status(400).json({ error: "invalid_client" });

  if (!client.public) {
    const secret = extractClientSecret(req);
    if (secret !== client.client_secret) return res.status(401).json({ error: "invalid_client", error_description: "client_secret 不正确" });
  }

  const entry = authCodes.get(code);
  if (!entry || entry.expiresAt < Date.now()) return res.status(400).json({ error: "invalid_grant" });
  if (entry.client_id !== client_id || entry.redirect_uri !== redirect_uri) return res.status(400).json({ error: "invalid_grant" });
  if (!verifyPkce(code_verifier, entry.code_challenge)) return res.status(400).json({ error: "invalid_grant", error_description: "PKCE校验失败" });

  authCodes.delete(code);
  const accessToken = randomToken(32);
  await saveToken(accessToken, { client_id, name: client.name || "未命名连接", createdAt: Date.now() });
  // 永久有效：不设置 expires_in 上限逻辑，只是象征性给一个很长的数字满足部分客户端要求
  res.json({ access_token: accessToken, token_type: "Bearer", expires_in: 3153600000 });
});

function requireAuth(req, res, next) {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  if (!token || !tokenCache.has(token)) {
    res.set("WWW-Authenticate", `Bearer realm="${BASE_URL}"`);
    return res.status(401).json({ error: "invalid_token" });
  }
  next();
}

// ============ 工作区清理 ============
// 工作区文件不会自动删除。只有以下两种途径能清空，且都必须验证身份：
//   1) Agent(exec调用cleanup_workspace工具) —— 必须携带正确密码
//   2) 网页Dashboard点击清空按钮 —— 必须验证密码 或 Passkey（仅网页支持）
async function cleanWorkspace() {
  const entries = await fs.readdir(WORKDIR, { withFileTypes: true });
  await Promise.all(entries.map((e) => fs.rm(path.join(WORKDIR, e.name), { recursive: true, force: true })));
}

// 网页端"二次验证令牌"：Passkey验证通过后签发，短时有效、一次性，专门用来授权这次删除操作
const stepupTokens = new Map(); // stepupToken -> { sid, expiresAt }

// ============ 危险命令检测 ============
const DANGEROUS_PATTERNS = [
  /\brm\s+(-\w*r\w*f\w*|-\w*f\w*r\w*)\s/i,
  /\brm\s+.*(-r|-f).*\s\/(\s|$)/i,
  /\bmkfs\b/i,
  /\bdd\s+if=.*of=\/dev\//i,
  /:\(\)\{.*\|.*&\};:/,
  /\bshutdown\b/i, /\breboot\b/i,
  /\bchmod\s+-R\s+777\s+\//i,
  /\bchown\s+-R\s+.*\s+\//i,
  />\s*\/dev\/sd[a-z]/i,
  /\bkill\s+-9\s+1\b/i,
  /\bdrop\s+database\b/i,
];
function isDangerous(command) { return DANGEROUS_PATTERNS.some((re) => re.test(command)); }

// ============ MCP 工具定义 ============
const MCP_INSTRUCTIONS = `JMCP 把一台真实的远程 Linux 服务器（VPS）交给你使用。
你可以用这里的工具在这台服务器上执行 shell 命令、读写文件、管理一个专属工作目录——
就像通过 SSH 登录了这台机器一样。适用场景包括：帮用户跑脚本、装软件、处理文件、
部署代码、调试环境、做用户要求的任何需要"实际动手操作一台电脑"的任务。

工具说明：
- exec：执行任意 shell 命令。这是最核心的工具，能跑几乎任何 Linux 命令行操作。
  如果命令被判定为危险（如 rm -rf、格式化磁盘等破坏性操作），会被拒绝执行并要求
  confirmed:true 参数——收到这个信号后，你必须先在对话中明确询问用户是否同意，
  用户同意后才能带上 confirmed:true 重新调用，绝不能自行假设用户同意。
- read_file / write_file：读写工作目录内的文件。
- list_dir：查看工作目录内有什么文件。
- cleanup_workspace：删除工作目录里的所有文件。这个操作需要用户提供 JMCP 的登录密码
  作为 password 参数才会执行——如果用户想清空工作区，你需要先向用户索要密码，绝不能
  在没有密码的情况下调用，也不要替用户猜测或存储这个密码。
- screenshot / gui_click / gui_move_mouse / gui_type_text / gui_key_press：GUI图形界面操控工具，
  能截图查看屏幕、点击、打字、按键，前提是这台服务器装了 Xvfb/xdotool/scrot 且有权限运行——
  如果这台机器不支持（常见于共享虚拟主机），调用这些工具会明确返回"不可用"而不是报错崩溃，
  遇到这种情况直接告知用户这台服务器不支持GUI操控即可，不用反复重试。

工作目录是持久化的：这次任务留下的文件，下次连接还能读到，除非被显式清空。`;

function buildMcpServer() {
  const server = new McpServer({ name: "jmcp", version: "3.0.0" }, { instructions: MCP_INSTRUCTIONS });

  server.registerTool("exec", {
    description: "在一台真实的远程Linux服务器(VPS)上执行shell命令，就像SSH登录后敲命令一样，可以用来跑脚本、装软件包、处理文件、部署代码、调试环境等任何需要实际操作电脑的任务。返回stdout/stderr/exitCode。危险命令（如rm -rf、格式化磁盘等破坏性操作）会被拦截，必须先在对话中征得用户明确同意，然后带上confirmed=true才能重新调用执行——绝不能自行假设用户同意。",
    inputSchema: {
      command: z.string().describe("要执行的shell命令"),
      cwd: z.string().optional().describe("工作目录，默认为服务器预设的工作区"),
      timeoutMs: z.number().optional().describe("超时毫秒数，默认30000"),
      confirmed: z.boolean().optional().describe("对危险命令的显式确认，必须先征得用户同意才能设为true"),
    },
  }, async ({ command, cwd, timeoutMs, confirmed }) => {
    lastActivity = Date.now();
    if (isDangerous(command) && !confirmed) {
      return { content: [{ type: "text", text: JSON.stringify({ blocked: true, reason: "此命令被识别为危险操作。必须先征得用户明确同意，然后带上 confirmed:true 重新调用此工具才会执行。", command }, null, 2) }], isError: true };
    }
    try {
      const { stdout, stderr } = await exec(command, { cwd: cwd || WORKDIR, timeout: timeoutMs || 30_000, maxBuffer: 10 * 1024 * 1024 });
      return { content: [{ type: "text", text: JSON.stringify({ stdout, stderr, exitCode: 0 }, null, 2) }] };
    } catch (err) {
      return { content: [{ type: "text", text: JSON.stringify({ stdout: err.stdout || "", stderr: err.stderr || err.message, exitCode: err.code ?? 1 }, null, 2) }], isError: true };
    }
  });

  server.registerTool("read_file", { description: "读取远程服务器上的文件内容", inputSchema: { path: z.string().describe("文件路径，相对或绝对") } },
    async ({ path: p }) => {
      lastActivity = Date.now();
      const full = path.isAbsolute(p) ? p : path.join(WORKDIR, p);
      const content = await fs.readFile(full, "utf8");
      return { content: [{ type: "text", text: content }] };
    });

  server.registerTool("write_file", { description: "写入内容到远程服务器上的文件（覆盖）", inputSchema: { path: z.string().describe("文件路径，相对或绝对"), content: z.string().describe("要写入的内容") } },
    async ({ path: p, content }) => {
      lastActivity = Date.now();
      const full = path.isAbsolute(p) ? p : path.join(WORKDIR, p);
      await fs.mkdir(path.dirname(full), { recursive: true });
      await fs.writeFile(full, content, "utf8");
      return { content: [{ type: "text", text: `已写入 ${full}` }] };
    });

  server.registerTool("list_dir", { description: "列出远程服务器上某目录的文件/文件夹", inputSchema: { path: z.string().optional().describe("目录路径，默认为工作区根目录") } },
    async ({ path: p }) => {
      lastActivity = Date.now();
      const full = p ? (path.isAbsolute(p) ? p : path.join(WORKDIR, p)) : WORKDIR;
      const entries = await fs.readdir(full, { withFileTypes: true });
      const listing = entries.map((e) => `${e.isDirectory() ? "d" : "f"} ${e.name}`).join("\n");
      return { content: [{ type: "text", text: listing || "(空目录)" }] };
    });

  server.registerTool("cleanup_workspace", {
    description: "清空工作区内的所有文件。这是破坏性操作，必须先向用户索要JMCP的登录密码，作为password参数传入才会真正执行——绝不能在没有密码或密码错误的情况下认为已经清空。",
    inputSchema: { password: z.string().describe("JMCP登录密码，必须先向用户询问获取，不能自行猜测或使用之前对话中出现过的值") },
  }, async ({ password }) => {
    if (!verifyPassword(password || "", passwordRecord)) {
      return { content: [{ type: "text", text: JSON.stringify({ ok: false, reason: "密码不正确，工作区未被清空。请向用户重新确认密码后再试。" }, null, 2) }], isError: true };
    }
    await cleanWorkspace();
    lastActivity = Date.now();
    return { content: [{ type: "text", text: "工作区已清空" }] };
  });

  // ============ GUI 操控工具（依赖宿主机是否装了 Xvfb/xdotool/scrot）============
  function guiUnavailableResult() {
    return {
      content: [{
        type: "text",
        text: JSON.stringify({
          available: false,
          reason: "这台服务器没有安装GUI操控所需的组件(Xvfb/xdotool/scrot)，或者没有权限安装（常见于共享虚拟主机）。GUI功能只能在有root权限、能自行安装系统软件包的服务器（如自己管理的VPS）上使用。",
        }, null, 2),
      }],
      isError: true,
    };
  }

  server.registerTool("screenshot", {
    description: "截取远程服务器虚拟屏幕的当前画面，用于查看GUI程序的界面状态。仅在宿主机支持GUI操控时可用。",
    inputSchema: {},
  }, async () => {
    if (!GUI_ENABLED) return guiUnavailableResult();
    lastActivity = Date.now();
    const shotPath = path.join(os.tmpdir(), `jmcp-shot-${Date.now()}.png`);
    try {
      await execFile("scrot", ["-o", shotPath], { env: guiEnv() });
      const buf = await fs.readFile(shotPath);
      await fs.rm(shotPath, { force: true });
      return { content: [{ type: "image", data: buf.toString("base64"), mimeType: "image/png" }] };
    } catch (err) {
      return { content: [{ type: "text", text: `截图失败: ${err.message}` }], isError: true };
    }
  });

  server.registerTool("gui_click", {
    description: "在远程服务器的虚拟屏幕上点击指定坐标。仅在宿主机支持GUI操控时可用，点击前建议先screenshot确认坐标。",
    inputSchema: {
      x: z.number().describe("横坐标"),
      y: z.number().describe("纵坐标"),
      button: z.enum(["left", "middle", "right"]).optional().describe("鼠标按键，默认left"),
      doubleClick: z.boolean().optional().describe("是否双击，默认false"),
    },
  }, async ({ x, y, button, doubleClick }) => {
    if (!GUI_ENABLED) return guiUnavailableResult();
    lastActivity = Date.now();
    const btnMap = { left: "1", middle: "2", right: "3" };
    const btn = btnMap[button || "left"];
    try {
      const args = ["mousemove", String(x), String(y), "click"];
      if (doubleClick) args.push("--repeat", "2");
      args.push(btn);
      await execFile("xdotool", args, { env: guiEnv() });
      return { content: [{ type: "text", text: `已点击 (${x}, ${y})` }] };
    } catch (err) {
      return { content: [{ type: "text", text: `点击失败: ${err.message}` }], isError: true };
    }
  });

  server.registerTool("gui_move_mouse", {
    description: "移动鼠标到指定坐标，不点击。仅在宿主机支持GUI操控时可用。",
    inputSchema: { x: z.number(), y: z.number() },
  }, async ({ x, y }) => {
    if (!GUI_ENABLED) return guiUnavailableResult();
    lastActivity = Date.now();
    try {
      await execFile("xdotool", ["mousemove", String(x), String(y)], { env: guiEnv() });
      return { content: [{ type: "text", text: `鼠标已移动到 (${x}, ${y})` }] };
    } catch (err) {
      return { content: [{ type: "text", text: `移动失败: ${err.message}` }], isError: true };
    }
  });

  server.registerTool("gui_type_text", {
    description: "在当前聚焦的输入框里输入文字，模拟键盘打字。仅在宿主机支持GUI操控时可用。",
    inputSchema: { text: z.string().describe("要输入的文字") },
  }, async ({ text }) => {
    if (!GUI_ENABLED) return guiUnavailableResult();
    lastActivity = Date.now();
    try {
      // 用 execFile 数组参数传递，不经过shell解析，避免特殊字符注入问题
      await execFile("xdotool", ["type", "--clearmodifiers", "--", text], { env: guiEnv() });
      return { content: [{ type: "text", text: "已输入文字" }] };
    } catch (err) {
      return { content: [{ type: "text", text: `输入失败: ${err.message}` }], isError: true };
    }
  });

  server.registerTool("gui_key_press", {
    description: "模拟按键，比如 Return(回车)、Tab、Escape、ctrl+c、alt+Tab 等xdotool支持的按键名。仅在宿主机支持GUI操控时可用。",
    inputSchema: { key: z.string().describe("按键名，xdotool key语法，比如 'Return'、'ctrl+c'、'alt+Tab'") },
  }, async ({ key }) => {
    if (!GUI_ENABLED) return guiUnavailableResult();
    lastActivity = Date.now();
    try {
      await execFile("xdotool", ["key", key], { env: guiEnv() });
      return { content: [{ type: "text", text: `已按下 ${key}` }] };
    } catch (err) {
      return { content: [{ type: "text", text: `按键失败: ${err.message}` }], isError: true };
    }
  });

  return server;
}

app.post("/mcp", requireAuth, async (req, res) => {
  try {
    const server = buildMcpServer();
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
    res.on("close", () => { transport.close(); server.close(); });
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (err) {
    console.error("MCP错误:", err);
    if (!res.headersSent) res.status(500).json({ jsonrpc: "2.0", error: { code: -32603, message: "内部错误" }, id: null });
  }
});
app.get("/mcp", requireAuth, (req, res) => res.status(405).json({ error: "method_not_allowed" }));

app.get("/", (req, res) => res.redirect("/dashboard"));

app.listen(PORT, () => {
  console.log(`JMCP 启动，监听端口 ${PORT}`);
  console.log(`BASE_URL = ${BASE_URL}`);
  console.log(`WORKDIR  = ${WORKDIR}`);
  console.log(`RP_ID    = ${RP_ID}`);
});
