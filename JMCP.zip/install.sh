#!/bin/sh
# install.sh — JMCP 一键安装脚本
# 用法: sh install.sh

set -e

echo "════════════════════════════════════"
echo "  JMCP 一键安装"
echo "════════════════════════════════════"
echo ""
printf "Language / 语言 [1=中文 / 2=English, default 1]: "
read -r LANG_CHOICE
case "$LANG_CHOICE" in
  2|en|EN|English) LANG=en ;;
  *) LANG=zh ;;
esac

if [ "$LANG" = "en" ]; then
  T_TITLE="JMCP Installer"
  T_NODE="Node.js was not found. Enable Node.js in your VPS hosting panel first."
  T_NODEVER="Node.js version is too old (current %s), version 18+ is required."
  T_NPM="npm was not found."
  T_INSTALL="Installing dependencies (this may take 1-2 minutes)..."
  T_DONE="Dependencies installed."
  T_EXISTS="An existing .env file was found. Overwrite and reconfigure? (y/N): "
  T_SKIP="Skipped configuration; using the existing .env."
  T_BASE="Public HTTPS URL"
  T_BASE_DESC="This must be the complete HTTPS URL reachable from the Internet. A domain is required. Direct IP addresses are not supported."
  T_BASE_EX="Example: https://your-domain.example"
  T_BASE_PROMPT="Enter BASE_URL: "
  T_PASSWORD="Initial admin password"
  T_PASSWORD_DESC="Used for Dashboard login and authorization. Leave blank to generate a random strong password."
  T_PASSWORD_PROMPT="Enter password (8+ characters, blank = auto-generate): "
  T_GENERATED="Generated password (shown only once; save it securely):"
  T_SHORT="Password must be at least 8 characters. Installation aborted."
  T_CONFIG="Configuration written to .env."
  T_GUI="Optional GUI control"
  T_GUI_DESC="Allows AI clients to take screenshots and control a graphical interface."
  T_VNC="If this machine already runs VNC/a desktop, enter its display number (e.g. :1). Press Enter if none: "
  T_GUI_INSTALL="Install xdotool + scrot now? (y/N): "
  T_GUI_DONE="Installed. JMCP will use the existing display on next startup."
  T_GUI_NO="No apt-get/sudo detected; install xdotool and scrot manually if needed."
  T_GUI_X="No existing display detected. Xvfb + xdotool + scrot are required for GUI control."
  T_GUI_XINSTALL="Install GUI components now? (y/N): "
  T_GUI_XDONE="GUI components installed; they will be enabled on next startup."
  T_GUI_SKIP="GUI component installation skipped."
  T_GUI_FAIL="Installation failed, possibly because sudo permission is unavailable. GUI control will be disabled."
  T_COMPLETE="Installation complete!"
  T_START="Start with: npm start"
  T_WORK="Agent workspace: \\$HOME/mcp-workspace"
  T_DASH="Dashboard: $BASE_URL/dashboard"
  T_CONNECT="MCP URL: $BASE_URL/mcp"
  T_AUTH="Authentication: OAuth"
else
  T_TITLE="JMCP 一键安装"
  T_NODE="没找到 node，请先在 VPS 后台启用 Node.js 环境"
  T_NODEVER="Node版本过低 (当前 %s)，需要 18 以上"
  T_NPM="没找到 npm"
  T_INSTALL="安装依赖包（可能需要1-2分钟，请耐心等待）..."
  T_DONE="依赖安装完成。"
  T_EXISTS="检测到已存在 .env 文件，是否覆盖重新配置？(y/N): "
  T_SKIP="跳过配置，使用现有 .env。"
  T_BASE="配置访问地址"
  T_BASE_DESC="必须填写外网可访问的完整 HTTPS 地址。必须有域名，不能直接使用 IP 地址。"
  T_BASE_EX="例如: https://你的域名.example"
  T_BASE_PROMPT="请输入 BASE_URL: "
  T_PASSWORD="设置初始登录密码"
  T_PASSWORD_DESC="用于 Dashboard 登录和授权连接。留空则自动生成随机强密码。"
  T_PASSWORD_PROMPT="请输入密码（至少8位，留空自动生成）: "
  T_GENERATED="已自动生成密码（只显示这一次，请妥善保存）："
  T_SHORT="密码至少8位，安装终止。"
  T_CONFIG="配置已写入 .env。"
  T_GUI="可选：GUI操控支持"
  T_GUI_DESC="让AI客户端能够截图、点击、打字操作图形界面。"
  T_VNC="如果这台机器已经在运行 VNC/桌面，输入 display 号（例如 :1）；没有则直接回车: "
  T_GUI_INSTALL="现在安装 xdotool + scrot？(y/N): "
  T_GUI_DONE="安装完成，下次启动 JMCP 会接管现有显示器。"
  T_GUI_NO="未检测到 apt-get/sudo，需要时请手动安装 xdotool 和 scrot。"
  T_GUI_X="没有现成显示器，需要 Xvfb + xdotool + scrot 才能使用 GUI 操控。"
  T_GUI_XINSTALL="现在安装 GUI 组件？(y/N): "
  T_GUI_XDONE="GUI组件安装完成，下次启动服务会自动启用。"
  T_GUI_SKIP="跳过 GUI 组件安装。"
  T_GUI_FAIL="安装失败，可能没有 sudo 权限。GUI 功能将自动停用。"
  T_COMPLETE="安装完成！"
  T_START="启动命令: npm start"
  T_WORK="Agent工作区默认路径: \\$HOME/mcp-workspace"
  T_DASH="首次访问 Dashboard: $BASE_URL/dashboard"
  T_CONNECT="MCP URL: $BASE_URL/mcp"
  T_AUTH="鉴权方式: OAuth"
fi

echo "════════════════════════════════════"
echo "  $T_TITLE"
echo "════════════════════════════════════"
echo ""

if ! command -v node >/dev/null 2>&1; then
  printf "❌ %s\n" "$T_NODE"
  exit 1
fi

NODE_MAJOR=$(node -e "console.log(process.versions.node.split('.')[0])")
if [ "$NODE_MAJOR" -lt 18 ]; then
  printf "❌ $T_NODEVER\n" "$(node -v)"
  exit 1
fi
echo "✅ Node版本: $(node -v)"

if ! command -v npm >/dev/null 2>&1; then
  printf "❌ %s\n" "$T_NPM"
  exit 1
fi
echo "✅ npm版本: $(npm -v)"
echo ""

echo "==> $T_INSTALL"
npm install
echo "✅ $T_DONE"
echo ""

if [ -f .env ]; then
  echo "⚠️  检测到已存在 .env 文件"
  printf "%s" "$T_EXISTS"
  read -r OVERWRITE
  if [ "$OVERWRITE" != "y" ] && [ "$OVERWRITE" != "Y" ]; then
    echo "$T_SKIP"
    echo ""
    echo "════════════════════════════════════"
    echo "$T_START"
    echo "════════════════════════════════════"
    exit 0
  fi
fi

echo "──── $T_BASE ────"
echo "$T_BASE_DESC"
echo "$T_BASE_EX"
printf "%s" "$T_BASE_PROMPT"
read -r BASE_URL
while :; do
  if [ -z "$BASE_URL" ]; then
    printf "%s" "$T_BASE_PROMPT"
    read -r BASE_URL
    continue
  fi
  if BASE_URL_VALUE="$BASE_URL" node - <<'NODE'
const raw = process.env.BASE_URL_VALUE;
try {
  const u = new URL(raw);
  const host = u.hostname;
  const ipv4 = /^(?:\d{1,3}\.){3}\d{1,3}$/.test(host);
  const ipv6 = host.includes(':');
  if (u.protocol !== 'https:' || ipv4 || ipv6 || host === 'localhost' || !host.includes('.')) process.exit(1);
} catch { process.exit(1); }
NODE
  then
    break
  fi
  if [ "$LANG" = "en" ]; then
    echo "❌ BASE_URL must be an HTTPS domain name. Direct IP addresses are not supported."
  else
    echo "❌ BASE_URL 必须是 HTTPS 域名，不能直接使用 IP 地址。"
  fi
  BASE_URL=""
done

echo ""
echo "──── $T_PASSWORD ────"
echo "$T_PASSWORD_DESC"
echo ""
printf "%s" "$T_PASSWORD_PROMPT"
stty -echo 2>/dev/null && HIDE_OK=1 || HIDE_OK=0
read -r ADMIN_PASSWORD
[ "$HIDE_OK" = "1" ] && stty echo 2>/dev/null && echo ""

if [ -z "$ADMIN_PASSWORD" ]; then
  ADMIN_PASSWORD=$(node -e "console.log(require('crypto').randomBytes(12).toString('base64url'))")
  echo "$T_GENERATED"
  echo ""
  echo "  >>> $ADMIN_PASSWORD <<<"
  echo ""
elif [ "${#ADMIN_PASSWORD}" -lt 8 ]; then
  echo "❌ $T_SHORT"
  exit 1
fi

cat > .env << EOF
BASE_URL=$BASE_URL
ADMIN_PASSWORD=$ADMIN_PASSWORD
EOF

rm -rf data/password.json data/passkeys.json data/manual-clients.json data/tokens 2>/dev/null || true
mkdir -p data/tokens

echo "✅ $T_CONFIG"
echo ""

# ---------- 5. 可选：GUI操控支持 ----------
echo "──── $T_GUI ────"
echo "$T_GUI_DESC"
echo ""
echo "如果这台机器已经在跑VNC（有真实桌面），直接告诉JMCP用哪个display号就行，不用装任何东西"
printf "%s" "$T_VNC"
read -r VNC_DISPLAY

if [ -n "$VNC_DISPLAY" ]; then
  # 自动补上冒号前缀，容错用户输入 "1" 而不是 ":1"
  case "$VNC_DISPLAY" in
    :*) : ;;
    *) VNC_DISPLAY=":$VNC_DISPLAY" ;;
  esac
  echo "GUI_DISPLAY=$VNC_DISPLAY" >> .env
  echo "✅ 已设置 GUI_DISPLAY=$VNC_DISPLAY"
  echo ""
  echo "$T_GUI_DESC"
  if command -v sudo >/dev/null 2>&1 && command -v apt-get >/dev/null 2>&1; then
    printf "%s" "$T_GUI_INSTALL"
    read -r INSTALL_TOOLS
    if [ "$INSTALL_TOOLS" = "y" ] || [ "$INSTALL_TOOLS" = "Y" ]; then
      sudo apt-get update -qq && sudo apt-get install -y xdotool scrot
      if [ $? -eq 0 ]; then
        echo "✅ $T_GUI_DONE"
      else
        echo "⚠️  $T_GUI_FAIL"
      fi
    fi
  else
    echo "⚠️  $T_GUI_NO"
  fi
else
  echo "$T_GUI_X"
  echo "$T_GUI_X"
  if command -v sudo >/dev/null 2>&1 && command -v apt-get >/dev/null 2>&1; then
    printf "%s" "$T_GUI_XINSTALL"
    read -r INSTALL_GUI
    if [ "$INSTALL_GUI" = "y" ] || [ "$INSTALL_GUI" = "Y" ]; then
      sudo apt-get update -qq && sudo apt-get install -y xvfb xdotool scrot
      if [ $? -eq 0 ]; then
        echo "✅ $T_GUI_XDONE"
      else
        echo "⚠️  $T_GUI_FAIL"
      fi
    else
      echo "$T_GUI_SKIP"
    fi
  else
    echo "$T_GUI_NO"
  fi
fi
echo ""
echo "════════════════════════════════════"
echo "  $T_COMPLETE"
echo "════════════════════════════════════"
echo ""
echo "$T_START"
echo ""
echo "$T_WORK"
echo ""
echo "$T_DASH"
echo ""
echo "$T_CONNECT"
echo "$T_AUTH"
echo "════════════════════════════════════"
